def lambda_handler(event:, context:)
  "Hello, world!"
end

